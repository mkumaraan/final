import { Routes } from '@angular/router';
import { LoginComponent } from './components/pages/login/login.component';
import { RegisterComponent } from './components/pages/register/register.component';
import { HomeComponent } from './components/pages/home/home.component';
import { AdminComponent } from './components/pages/admin/admin.component';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { inject } from '@angular/core'; // Import inject
import { LandingComponent } from './components/pages/landing/landing.component';
import { UnauthorizedComponent } from './components/pages/unauthorized/unauthorized.component';

const nav: CanActivateFn = (route, state) => {
    const authService = inject(AuthService); // Inject the AuthService
    const router = inject(Router);

    if (authService.canActivate()) {
        return true;
    } else {
        return false;
    }
};

export const routes: Routes = [
    { path: '', component: LandingComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'login', component: LoginComponent },
    { path: 'home', component: HomeComponent, canActivate: [nav] },
    { path: 'admin', component: AdminComponent, canActivate: [nav] },
    {path: 'unauthorized', component: UnauthorizedComponent},
    { path: '**', redirectTo: '', pathMatch: 'full' },
];