export interface State{
  stateId: number;
  name: string;
}