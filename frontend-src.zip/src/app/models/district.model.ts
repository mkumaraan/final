import { State } from "./state.model";
export interface District{
  districtId:number;
  name:string;
  state:State;
  stateId:number
}