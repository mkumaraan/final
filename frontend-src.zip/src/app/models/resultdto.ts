export interface ResultDTO{
  stateName:string;
  districtName:string;
  partyName:string;
  leaderName:string;
  votes:number;
}