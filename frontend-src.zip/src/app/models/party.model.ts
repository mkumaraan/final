export interface Party{
  partyId:number;
  name:string;
  leaderName:string;
  districtId:number;
  symbolImage: string | null; 
}