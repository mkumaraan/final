import { Party } from "./party.model";

export interface Candidate { 
  partiesInDistrict: Party[];
  candidateId: number; 
  name: string; 
  email: string; 
  age: number; 
  gender: string; 
  districtId: number; 
  hasVoted: boolean; 
  role:string; 
 }