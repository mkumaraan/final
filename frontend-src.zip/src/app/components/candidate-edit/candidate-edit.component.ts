import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { CommonModule } from '@angular/common';
import { Candidate } from '../../models/candidate.model';

@Component({
  selector: 'app-candidate-edit',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './candidate-edit.component.html',
  styleUrls: ['./candidate-edit.component.css']
})
export class CandidateEditComponent implements OnChanges {
  @Input() selectedCandidate: Candidate | null = null;
  @Output() candidateUpdated = new EventEmitter<void>();
  @Output() candidateDeleted = new EventEmitter<void>();
  @Output() candidateCancelled = new EventEmitter<void>(); // to clear the selected candidate

  candidateForm: FormGroup;
  selectedCandidateId: number = 0;
  isLoading = false;

  constructor(private apiService: ApiService) {
    this.candidateForm = new FormGroup({
      name: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl(''), // Optional
      age: new FormControl(0, [Validators.required, Validators.min(18)]),
      gender: new FormControl('', Validators.required),
      districtId: new FormControl(0, Validators.required),
      role: new FormControl('', Validators.required)
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedCandidate'] && this.selectedCandidate) {
      this.selectedCandidateId = this.selectedCandidate.candidateId;
      this.candidateForm.patchValue({
        name: this.selectedCandidate.name,
        email: this.selectedCandidate.email,
        age: this.selectedCandidate.age,
        gender: this.selectedCandidate.gender,
        districtId: this.selectedCandidate.districtId,
        role: this.selectedCandidate.role
      });
    }
  }

  updateCandidate() {
    if (!this.selectedCandidateId || this.candidateForm.invalid) return;

    this.isLoading = true;
    this.apiService.updateCandidate(this.selectedCandidateId, this.candidateForm.value).subscribe(
      (candidate) => {
        console.log(candidate);
        this.isLoading = false;
        alert("Candidate Updated Successfully!");
        this.candidateUpdated.emit(); // Notify parent
        this.cancelEdit();
      },
      (error) => {
        this.isLoading = false;
        alert(error.error?.message || "Error updating candidate");
      }
    );
  }

  deleteCandidate() {
    if (!this.selectedCandidateId) {
      alert("No candidate selected!");
      return;
    }

    this.isLoading = true;
    this.apiService.deleteCandidate(this.selectedCandidateId).subscribe(
      () => {
        console.log(`Candidate with ID ${this.selectedCandidateId} deleted.`);
        this.isLoading = false;
        alert("Candidate Deleted Successfully!");
        this.candidateDeleted.emit(); // Notify parent
        this.cancelEdit();
      },
      (error) => {
        this.isLoading = false;
        console.error("Delete error:", error);
        alert(error.error?.message || "Error deleting candidate");
      }
    );
  }

  cancelEdit() {
    this.selectedCandidate = null;
    this.selectedCandidateId = 0;
    this.candidateCancelled.emit();
  }
}
