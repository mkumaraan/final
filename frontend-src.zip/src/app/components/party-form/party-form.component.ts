import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { District } from '../../models/district.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-party-form',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './party-form.component.html',
  styleUrls: ['./party-form.component.css']
})
export class PartyFormComponent implements OnInit {
  partyForm!: FormGroup;
  isLoading = false;
  @Output() partyCreated = new EventEmitter<void>();
  @Output() partyDeleted = new EventEmitter<void>();
  @Input() districts: District[] = [];
  parties: any = [];

  constructor(private apiService: ApiService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.initForm();
    this.fetchParties();
  }

  initForm() {
    this.partyForm = this.fb.group({
      name: ['', Validators.required],
      leaderName: ['', Validators.required],
      districtId: [0, Validators.required]
    });
  }

  fetchParties() {
    this.apiService.getAllParties().subscribe({
      next: (parties) => {
        this.parties = parties || [];
      },
      error: (error) => {
        console.error('Error fetching parties:', error);
      }
    });
  }

  createParty() {
    if (this.partyForm.invalid) {
      alert('Please fill out all fields correctly.');
      return;
    }

    this.isLoading = true;
    this.apiService.createParty(this.partyForm.value).subscribe({
      next: (response) => {
        console.log('Party Created:', response);
        this.isLoading = false;
        alert('Party Created Successfully!');
        this.partyCreated.emit();
        this.partyForm.reset(); // Clear form
        this.fetchParties();
      },
      error: (error) => {
        this.isLoading = false;
        alert(error.error?.message || 'Error creating party');
      }
    });
  }

  deleteParty(partyId: number) {
    if (confirm('Are you sure you want to delete this party?')) {
      this.apiService.deleteParty(partyId).subscribe({
        next: () => {
          this.parties = this.parties.filter((party: { partyId: number }) => party.partyId !== partyId);
          alert('Party deleted successfully');
          this.partyDeleted.emit();
        },
        error: (error) => {
          console.error('Error deleting party:', error);
          alert(error.error?.message || "Error deleting party");
        }
      });
    }
  }
}
