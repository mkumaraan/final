import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { CommonModule } from '@angular/common';
import { State } from '../../models/state.model';
import { District } from '../../models/district.model';

@Component({
  selector: 'app-district-form',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './district-form.component.html',
  styleUrls: ['./district-form.component.css']
})
export class DistrictFormComponent implements OnInit {
  districtForm!: FormGroup;
  isLoading = false;
  
  @Input() districts: District[] = [];
  @Output() districtCreated = new EventEmitter<void>();
  @Output() districtDeleted = new EventEmitter<void>();
  @Input() states: State[] = [];

  constructor(private apiService: ApiService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.districtForm = this.fb.group({
      name: ['', Validators.required],
      stateId: [null, Validators.required]
    });

    this.fetchDistricts();
    this.fetchStates();
  }

  fetchDistricts() {
    this.apiService.getAllDistricts().subscribe({
      next: (districts) => {
        this.districts = districts;
      },
      error: (error) => {
        console.error('Error fetching districts:', error);
      }
    });
  }

  fetchStates() {
    this.apiService.getAllStates().subscribe({
      next: (states) => {
        this.states = states;
      },
      error: (error) => {
        console.error('Error fetching states:', error);
      }
    });
  }

  createDistrict() {
    if (this.districtForm.invalid) {
      alert("Please enter district name and select a valid state.");
      return;
    }

    this.isLoading = true;
    this.apiService.createDistrict(this.districtForm.value).subscribe({
      next: () => {
        this.isLoading = false;
        alert("District Created Successfully!");
        this.districtCreated.emit();
        this.districtForm.reset();
        this.fetchDistricts();
      },
      error: (error) => {
        this.isLoading = false;
        alert(error.error?.message || "Error creating district");
      }
    });
  }

  deleteDistrict(districtId: number) {
    if (confirm('Are you sure you want to delete this district?')) {
      this.apiService.deleteDistrict(districtId).subscribe({
        next: () => {
          this.districts = this.districts.filter(district => district.districtId !== districtId);
          alert('District deleted successfully');
          this.districtDeleted.emit();
        },
        error: (error) => {
          alert(error.error?.message || "Error deleting district");
        }
      });
    }
  }
}
