import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { State } from '../../models/state.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-state-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './state-form.component.html',
  styleUrls: ['./state-form.component.css']
})
export class StateFormComponent implements OnInit {
  stateForm!: FormGroup;
  isLoading = false;
  @Output() stateCreated = new EventEmitter<void>();
  @Output() stateDeleted = new EventEmitter<void>();
  states: State[] = [];

  constructor(private apiService: ApiService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForm();
    this.fetchStates();
  }

  initForm() {
    this.stateForm = this.fb.group({
      name: ['', Validators.required]
    });
  }

  fetchStates() {
    this.apiService.getAllStates().subscribe({
      next: (states) => {
        this.states = states || [];
      },
      error: (error) => {
        console.error('Error fetching states:', error);
      }
    });
  }

  createState() {
    if (this.stateForm.invalid) {
      alert('Please enter a state name.');
      return;
    }

    this.isLoading = true;
    this.apiService.createState(this.stateForm.value).subscribe({
      next: (response) => {
        console.log('State Created:', response);
        this.isLoading = false;
        alert('State Created Successfully!');
        this.stateCreated.emit();
        this.stateForm.reset(); // Clear form
        this.fetchStates();
      },
      error: (error) => {
        this.isLoading = false;
        alert(error.error?.message || 'Error creating state');
      }
    });
  }

  deleteState(stateId: number) {
    if (confirm('Are you sure you want to delete this state?')) {
      this.apiService.deleteState(stateId).subscribe({
        next: () => {
          this.states = this.states.filter(state => state.stateId !== stateId);
          alert('State deleted successfully');
          this.stateDeleted.emit();
        },
        error: (error) => {
          console.error('Error deleting state:', error);
          alert(error.error?.message || 'Error deleting state');
        }
      });
    }
  }
}
