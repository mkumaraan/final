import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../auth/auth.service';
import { ApiService } from '../../../services/api.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { Candidate } from '../../../models/candidate.model';
import { Party } from '../../../models/party.model';
import { ResultDTO } from '../../../models/resultdto';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user: Candidate | null = null;
  parties: Party[] = [];
  results: ResultDTO[] = [];
  voted = false;
  voteCasted = false;
  showVotePopup = false;
  voteConfirmationMessage = "";
  isLoading = false;

  // Define reactive form
  voteForm = new FormGroup({
    candidateId: new FormControl(0),
    partyId: new FormControl(null)  // Changed from number to null initially
  });

  constructor(private authService: AuthService, private apiService: ApiService, private router: Router) {}

  ngOnInit() {
    this.authService.loggedInUser.subscribe((user) => {
      this.user = user;
      if (user) {
        this.voteForm.controls['candidateId'].setValue(user.candidateId);
        if (user.role !== 'ADMIN') {
          this.getPartiesFromLogin(user);
          this.checkIfUserVoted();
        }
      }
    });
  }

  getPartiesFromLogin(user: Candidate) {
    console.log("User Data on Home Component:", user);

    if (user && user.partiesInDistrict && Array.isArray(user.partiesInDistrict) && user.partiesInDistrict.length > 0) {
      console.log("Fetched Parties from Backend:", user.partiesInDistrict);
      this.parties = user.partiesInDistrict;
    } else {
      console.error("No parties found or undefined:", user);
      alert("No parties found for this district.");
    }
  }

  logout() {
    this.authService.logout();
  }

  vote() {
    if (!this.user) {
      alert("User data not found. Please log in again.");
      return;
    }

    if (!this.voteForm.value.partyId) {
      alert("Please select a party and try again.");
      return;
    }

    this.isLoading = true;
    this.apiService.vote(this.voteForm.value).subscribe(
      (response) => {
        this.isLoading = false;
        console.log("Vote Response:", response);
        this.voteConfirmationMessage = response;
        this.voted = true;
        this.voteCasted = true;
        this.checkIfUserVoted();
        alert("Vote successfully cast");
      },
      (error) => {
        this.isLoading = false;
        console.error("Error submitting vote:", error);
        alert("You have already voted");
      }
    );
  }

  checkIfUserVoted() {
    this.voted = this.user?.hasVoted || false;
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToLanding() {
    this.router.navigate(['/']);
  }
}
