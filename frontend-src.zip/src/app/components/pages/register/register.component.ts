import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../../auth/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      age: [null, [Validators.required, Validators.min(18)]],
      gender: ['', Validators.required],
      districtId: [null, Validators.required],
      role: ['', Validators.required]
    });
  }

  register() {
    if (this.registerForm.invalid) {
      alert("Please fill all required fields correctly.");
      return;
    }

    this.authService.register(this.registerForm.value).subscribe(
      (response) => {
        console.log("Registration Successful:", response);
        alert("Registration Successful!");
        this.router.navigate(['/login']);
      },
      (error) => {
        console.error("Registration Failed:", error);
        alert("User name or Email already exists. Please try again!");
      }
    );
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToLanding() {
    this.router.navigate(['/']);
  }
}

