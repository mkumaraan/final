package com.cts.onlinevote.service;

import com.cts.onlinevote.dto.ResultDTO;
import com.cts.onlinevote.entity.*;
import com.cts.onlinevote.repo.ResultRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ResultServ {

    @Autowired
    private ResultRepo resultRepo;

    @Autowired
    private StateServ stateServ;

    @Autowired
    private DistrictServ districtServ;

    public Result saveResult(Result result) {
        return resultRepo.save(result);
    }

    public Optional<Result> getResultById(Long resultId) {
        return resultRepo.findById(resultId);
    }

    public List<Result> getResultsByDistrictId(Long districtId) {
        return resultRepo.findByDistrict_DistrictId(districtId);
    }

    public List<Result> getAllResults() {
        return resultRepo.findAll();
    }

    public void deleteResultById(Long resultId) {
        resultRepo.deleteById(resultId);
    }

    //to find the winning party
    public List<ResultDTO> getResults() {
        List<ResultDTO> resultDTOs = new ArrayList<>();
        List<State> states = stateServ.getAllStates();

        for (State state : states) {
            List<District> districts = districtServ.getDistrictsByStateId(state.getStateId());
            for (District district : districts) {
                List<Result> results = getResultsByDistrictId(district.getDistrictId());
                if (!results.isEmpty()) {
                    Result maxResult = results.stream().max(Comparator.comparingLong(Result::getVotes)).orElse(null);
                    if (maxResult != null) {
                        ResultDTO resultDTO = new ResultDTO();
                        resultDTO.setStateName(state.getName());
                        resultDTO.setDistrictName(district.getName());
                        resultDTO.setPartyName(maxResult.getParty().getName());
                        resultDTO.setLeaderName(maxResult.getParty().getLeaderName());
                        resultDTO.setVotes(maxResult.getVotes());
                        resultDTOs.add(resultDTO);
                    }
                }
            }
        }

        return resultDTOs;
    }

    public List<String> getFormattedResults() {
        List<ResultDTO> results = getResults();
        return results.stream()
                .map(ResultDTO::getFormattedResult)
                .collect(Collectors.toList());
    }
}