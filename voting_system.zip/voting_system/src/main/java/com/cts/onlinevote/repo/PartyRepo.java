package com.cts.onlinevote.repo;

import com.cts.onlinevote.entity.Party;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface PartyRepo extends JpaRepository<Party, Long> {
    List<Party> findByDistrictId(Long districtId);
}

