package com.cts.onlinevote.dto;

import jakarta.validation.constraints.NotEmpty;

public class StateDTO {

    @NotEmpty(message = "State name cannot be empty")
    private String name;

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}