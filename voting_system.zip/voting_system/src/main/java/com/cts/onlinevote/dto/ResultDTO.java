package com.cts.onlinevote.dto;

public class ResultDTO {

    private String stateName;
    private String districtName;
    private String partyName;
    private String leaderName;
    private Long votes;

    // Getters and Setters
    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public Long getVotes() {
        return votes;
    }

    public void setVotes(Long votes) {
        this.votes = votes;
    }

    public String getFormattedResult() {
        return "In the state "+stateName+
        		" ,the district "+districtName+
        		" ,the winning party was "+partyName+
        		" led by "+leaderName+
        		" ,with votes : "+votes;
    }
}