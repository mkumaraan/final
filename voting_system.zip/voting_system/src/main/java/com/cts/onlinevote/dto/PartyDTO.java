package com.cts.onlinevote.dto;

import jakarta.validation.constraints.NotEmpty;

public class PartyDTO {

    @NotEmpty(message = "Party name cannot be empty")
    private String name;

    @NotEmpty(message = "Leader name cannot be empty")
    private String leaderName;
    
    private byte[] symbolImage;

	public byte[] getSymbolImage() {
		return symbolImage;
	}

	public void setSymbolImage(byte[] symbolImage) {
		this.symbolImage = symbolImage;
	}

	private Long districtId;

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public Long getDistrictId() {
        return districtId;
    }

    public void setDistrictId(Long districtId) {
        this.districtId = districtId;
    }
}