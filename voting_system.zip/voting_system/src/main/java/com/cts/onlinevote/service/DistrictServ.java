package com.cts.onlinevote.service;

import com.cts.onlinevote.dto.DistrictDTO;
import com.cts.onlinevote.entity.*;
import com.cts.onlinevote.repo.DistrictRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DistrictServ {

    @Autowired
    private DistrictRepo districtRepo;

    @Autowired
    private StateServ stateServ;

    public District saveDistrict(DistrictDTO districtDTO) {
        District district = new District();
        district.setName(districtDTO.getName());

        State state = stateServ.getStateById(districtDTO.getStateId())
                .orElseThrow(() -> new RuntimeException("State not found"));
        district.setState(state);

        return districtRepo.save(district);
    }

    public Optional<District> getDistrictById(Long districtId) {
        return districtRepo.findById(districtId);
    }

    public List<District> getAllDistricts() {
        return districtRepo.findAll();
    }

    public List<District> getDistrictsByStateId(Long stateId) {
        return districtRepo.findByState_StateId(stateId);
    }

    public void deleteDistrictById(Long districtId) {
        Optional<District> districtOptional = districtRepo.findById(districtId);
        if(districtOptional.isPresent()) {
            District district = districtOptional.get();
            //cascade delete handled by JPA annotations, no need to explicitly delete parties here
            districtRepo.delete(district);
        } else {
            throw new IllegalArgumentException("District not found with id: " + districtId);
        }
    }
}

