package com.cts.onlinevote.service;

import com.cts.onlinevote.dto.PartyDTO;
import com.cts.onlinevote.entity.Party;
import com.cts.onlinevote.entity.Result;
import com.cts.onlinevote.repo.PartyRepo;
import com.cts.onlinevote.repo.ResultRepo;

import io.jsonwebtoken.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class PartyServ {

    @Autowired
    private PartyRepo partyRepo;

    @Autowired
    private ResultRepo resultRepo;  // Inject ResultRepo

    public Party saveParty(PartyDTO partyDTO) {
        Party party = new Party();
        party.setName(partyDTO.getName());
        party.setLeaderName(partyDTO.getLeaderName());
        party.setDistrictId(partyDTO.getDistrictId());
        party.setSymbolImage(partyDTO.getSymbolImage());

        return partyRepo.save(party);
    }

    public Optional<Party> getPartyById(Long partyId) {
        return partyRepo.findById(partyId);
    }

    public List<Party> getAllParties() {
        return partyRepo.findAll();
    }

    public void deletePartyById(Long partyId) {
        // 1. Find the party
        Optional<Party> partyOptional = partyRepo.findById(partyId);
        if (partyOptional.isPresent()) {
            Party party = partyOptional.get();

            // 2. Delete associated results.  Fetch all results associated with this party.
            List<Result> resultsToDelete = new ArrayList<>(resultRepo.findByParty_PartyId(partyId)); // Fix: Use partyId directly

            // Delete each of the results individually to avoid issues within the same transaction
            resultsToDelete.forEach(result -> resultRepo.delete(result));

            // 3. Finally, delete the party
            partyRepo.delete(party); // Fix: Delete the party using the Party object
        } else {
            throw new IllegalArgumentException("Party not found with id: " + partyId);
        }
    }

    public List<Party> getPartiesByDistrictId(Long districtId) {
        return partyRepo.findByDistrictId(districtId);
    }

    public void uploadPartySymbol(Long partyId, MultipartFile file) throws IOException, java.io.IOException {
        Optional<Party> optionalParty = partyRepo.findById(partyId);
        if (optionalParty.isEmpty()) {
            throw new IllegalArgumentException("Party not found with id: " + partyId);
        }

        Party party = optionalParty.get();
        party.setSymbolImage(file.getBytes());
        partyRepo.save(party);
    }
}