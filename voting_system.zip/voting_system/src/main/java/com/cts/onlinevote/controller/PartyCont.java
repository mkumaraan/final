package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.PartyDTO;
import com.cts.onlinevote.entity.Party;
import com.cts.onlinevote.service.PartyServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/parties")
public class PartyCont {

    @Autowired
    private PartyServ partyServ;

    @PostMapping
    public ResponseEntity<Party> createOrUpdateParty(@RequestBody PartyDTO partyDTO) {
        Party savedParty = partyServ.saveParty(partyDTO);
        return ResponseEntity.ok(savedParty);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Party>> getPartyById(@PathVariable Long id) {
        Optional<Party> party = partyServ.getPartyById(id);
        if (party.isPresent()) {
            return ResponseEntity.ok(party);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Party>> getAllParties() {
        List<Party> parties = partyServ.getAllParties();
        return ResponseEntity.ok(parties);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePartyById(@PathVariable Long id) {
        partyServ.deletePartyById(id);
        return ResponseEntity.noContent().build();
    }
}