package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.StateDTO;
import com.cts.onlinevote.entity.State;
import com.cts.onlinevote.service.StateServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/states")
public class StateCont {

    @Autowired
    private StateServ stateServ;

    @PostMapping
    public ResponseEntity<State> createOrUpdateState(@RequestBody StateDTO stateDTO) {
        State savedState = stateServ.saveState(stateDTO);
        return ResponseEntity.ok(savedState);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<State>> getStateById(@PathVariable Long id) {
        Optional<State> state = stateServ.getStateById(id);
        if (state.isPresent()) {
            return ResponseEntity.ok(state);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<State>> getAllStates() {
        List<State> states = stateServ.getAllStates();
        return ResponseEntity.ok(states);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStateById(@PathVariable Long id) {
        stateServ.deleteStateById(id);
        return ResponseEntity.noContent().build();
    }
}