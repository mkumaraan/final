package com.cts.onlinevote.service;

import com.cts.onlinevote.dto.StateDTO;
import com.cts.onlinevote.entity.State;
import com.cts.onlinevote.repo.StateRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StateServ {

    @Autowired
    private StateRepo stateRepo;

    public State saveState(StateDTO stateDTO) {
        State state = new State();
        state.setName(stateDTO.getName());

        return stateRepo.save(state);
    }

    public Optional<State> getStateById(Long stateId) {
        return stateRepo.findById(stateId);
    }

    public List<State> getAllStates() {
        return stateRepo.findAll();
    }

    public void deleteStateById(Long stateId) {
        Optional<State> stateOptional = stateRepo.findById(stateId);
        if (stateOptional.isPresent()) {
            State state = stateOptional.get();
            // Cascade delete handled by JPA annotations, no need to explicitly delete districts here
            stateRepo.delete(state);
        } else {
            throw new IllegalArgumentException("State not found with id: " + stateId);
        }
    }
}

