package com.cts.onlinevote.repo;

import com.cts.onlinevote.entity.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DistrictRepo extends JpaRepository<District, Long> {
    List<District> findByState_StateId(Long stateId);
}

