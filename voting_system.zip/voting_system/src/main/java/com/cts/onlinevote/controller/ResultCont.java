package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.ResultDTO;
import com.cts.onlinevote.entity.Result;
import com.cts.onlinevote.service.ResultServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/results")
public class ResultCont {

    @Autowired
    private ResultServ resultServ;

    @PostMapping
    public ResponseEntity<Result> createOrUpdateResult(@RequestBody Result result) {
        Result savedResult = resultServ.saveResult(result);
        return ResponseEntity.ok(savedResult);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Result>> getResultById(@PathVariable Long id) {
        Optional<Result> result = resultServ.getResultById(id);
        if (result.isPresent()) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Returns list of ResultDTO for table data
    @GetMapping
    public ResponseEntity<List<ResultDTO>> getAllResults() {
        List<ResultDTO> results = resultServ.getResults();
        return ResponseEntity.ok(results);
    }

    // New endpoint to get formatted string results
    @GetMapping("/formatted")
    public ResponseEntity<List<String>> getFormattedResults() {
        List<String> formattedResults = resultServ.getFormattedResults();
        return ResponseEntity.ok(formattedResults);
    }

    @GetMapping("/district/{districtId}")
    public ResponseEntity<List<Result>> getResultsByDistrictId(@PathVariable Long districtId) {
        List<Result> results = resultServ.getResultsByDistrictId(districtId);
        return ResponseEntity.ok(results);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteResultById(@PathVariable Long id) {
        resultServ.deleteResultById(id);
        return ResponseEntity.noContent().build();
    }
}