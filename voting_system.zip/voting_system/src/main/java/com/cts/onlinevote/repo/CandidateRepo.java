package com.cts.onlinevote.repo;

import com.cts.onlinevote.entity.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateRepo extends JpaRepository<Candidate, Long> {
    Candidate findByEmail(String email);
    List<Candidate> findByDistrictId(Long districtId);
    List<Candidate> findByRole(String role);
}