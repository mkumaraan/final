package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.*;
import com.cts.onlinevote.entity.Candidate;
import com.cts.onlinevote.service.CandidateServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

import java.security.Principal;
import java.util.Map;


@RestController
@RequestMapping("/api/candidates")
public class CandidateCont {

    @Autowired
    private CandidateServ candidateServ;
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/register")
    public ResponseEntity<?> registerCandidate(@Valid @RequestBody CandidateDTO candidateDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // Return validation errors
            FieldError fieldError = bindingResult.getFieldError();
            String errorMessage = fieldError != null ? fieldError.getDefaultMessage() : "Validation error";
            return ResponseEntity.badRequest().body(errorMessage);
        }

        Candidate registeredCandidate = candidateServ.registerCandidate(candidateDTO);
        return ResponseEntity.ok("Registration successful for candidate: " + registeredCandidate.getName());
    }
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/login") // requires authorization 
    public ResponseEntity<Map<String, Object>> loginCandidate(@RequestBody LoginDTO loginDTO) {
        Map<String, Object> response = candidateServ.loginCandidate(loginDTO.getEmail(), loginDTO.getPassword());
        response.put("message", "Login successful");
        return ResponseEntity.ok(response);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/vote")
    public ResponseEntity<String> castVote(@RequestBody VoteDTO voteDTO, Principal principal) {
        String authenticatedUserEmail = principal.getName(); // Get the authenticated user's email
        candidateServ.castVote(voteDTO.getCandidateId(), voteDTO.getPartyId(), authenticatedUserEmail);
        return ResponseEntity.ok("Vote successfully cast!");
    }
}