package com.cts.onlinevote.dto;

import jakarta.validation.constraints.NotEmpty;

public class DistrictDTO {

    @NotEmpty(message = "District name cannot be empty")
    private String name;

    //@NotEmpty(message = "State ID cannot be empty")
    private Long stateId;

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getStateId() {
        return stateId;
    }

    public void setStateId(Long stateId) {
        this.stateId = stateId;
    }
}