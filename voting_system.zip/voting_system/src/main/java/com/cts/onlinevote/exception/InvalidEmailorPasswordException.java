package com.cts.onlinevote.exception;

public class InvalidEmailorPasswordException extends RuntimeException{
	public InvalidEmailorPasswordException(String message) {
		super(message);
	}
}
