package com.cts.onlinevote.service;

import com.cts.onlinevote.dto.*;
import com.cts.onlinevote.entity.*;
import com.cts.onlinevote.exception.*;
import com.cts.onlinevote.repo.*;
import com.cts.onlinevote.utils.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.*;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service
public class CandidateServ {
	
	private static final Logger logger = LoggerFactory.getLogger(CandidateServ.class);

    @Autowired
    private CandidateRepo candidateRepo;
    
    @Autowired
    private PartyRepo partyRepo;

    @Autowired
    private ResultServ resultServ;
    
    @Autowired
    private DistrictRepo districtRepo;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;

    public Candidate saveCandidate(Candidate candidate) {
        return candidateRepo.save(candidate);
    }

    public Candidate registerCandidate(CandidateDTO candidateDTO) throws EmailAlreadyExistsException, InvalidRoleException {
    	logger.info("Attempting to register candidate with email: {}", candidateDTO.getEmail());
    	Candidate candidate = new Candidate();
        candidate.setName(candidateDTO.getName());
        candidate.setEmail(candidateDTO.getEmail());
        candidate.setPassword(passwordEncoder.encode(candidateDTO.getPassword()));
        candidate.setAge(candidateDTO.getAge());
        candidate.setGender(candidateDTO.getGender());
        candidate.setDistrictId(candidateDTO.getDistrictId());
        candidate.setRole(candidateDTO.getRole());

        if (candidateRepo.findByEmail(candidate.getEmail()) != null) {
        	logger.error("Email already exists: {}", candidate.getEmail());
        	throw new EmailAlreadyExistsException("Email already exists!");
        }

        // Validating
        if (!candidate.getRole().equals("ADMIN") && !candidate.getRole().equals("USER")) {
        	logger.error("Invalid role provided: {}", candidate.getRole());
        	throw new InvalidRoleException("Invalid role. Role must be either 'ADMIN' or 'USER'.");
        }

        Candidate savedCandidate = candidateRepo.save(candidate);
        logger.info("Candidate registered successfully with ID: {}", savedCandidate.getCandidateId());

        return savedCandidate;
    }

    public Map<String, Object> loginCandidate(String email, String password) {
        Candidate candidate = candidateRepo.findByEmail(email);
        if (candidate != null && passwordEncoder.matches(password, candidate.getPassword())) {
            // Fetch parties
            List<Party> partiesInDistrict = partyRepo.findByDistrictId(candidate.getDistrictId());

            String token = jwtUtil.generateToken(candidate);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login successful");
            response.put("candidate", candidate);
            response.put("partiesInDistrict", partiesInDistrict);
            response.put("token", token);

            return response;
        } else {
            throw new InvalidEmailorPasswordException("Invalid email or password");
        }
    }

    public void castVote(Long candidateId, Long partyId, String authenticatedUserEmail) {
        // Fetch the authenticated user
    	logger.info("Attempting to cast vote for candidate ID: {} and party ID: {}", candidateId, partyId);
    	Candidate authenticatedCandidate = candidateRepo.findByEmail(authenticatedUserEmail);
        if (authenticatedCandidate == null) {
        	logger.error("Authenticated user not found with email: {}", authenticatedUserEmail);
        	throw new CandidateNotFoundException("Authenticated user not found!");
        }

        // Ensure the authenticated user is casting their own vote
        if (!authenticatedCandidate.getCandidateId().equals(candidateId)) {
        	logger.error("Unauthorized attempt to cast vote for another user. Authenticated user ID: {}, Requested candidate ID: {}", authenticatedCandidate.getCandidateId(), candidateId);
        	throw new UnauthorizedException("You are unauthorized to cannot cast a vote for another candidate.");
        }

        // Fetch the candidate and party
        Optional<Candidate> candidateOpt = candidateRepo.findById(candidateId);
        if (candidateOpt.isEmpty()) {
        	logger.error("Candidate not found with ID: {}", candidateId);
            throw new CandidateNotFoundException("Candidate not found!");
        }

        Optional<Party> partyOpt = partyRepo.findById(partyId);
        if (partyOpt.isEmpty()) {
        	logger.error("Party not found with ID: {}", partyId);
            throw new PartyNotFoundException("Party not found!");
        }

        Candidate candidate = candidateOpt.get();
        Party party = partyOpt.get();

        // Ensure the candidate has not already voted
        if (candidate.isHasVoted()) {
        	logger.error("Candidate has already voted. Candidate ID: {}", candidateId);
            throw new CandidatehasalreadyVotedException("Candidate has already voted!");
        }

        // Mark the candidate as having voted
        candidate.setHasVoted(true);
        candidateRepo.save(candidate);
        logger.info("Vote cast successfully for candidate ID: {} and party ID: {}", candidateId, partyId);

        // Update the vote count for the party in the candidate's district
        List<Result> results = resultServ.getResultsByDistrictId(candidate.getDistrictId());
        Result result = results.stream()
                .filter(r -> r.getParty().getPartyId().equals(partyId))
                .findFirst()
                .orElse(null);

        if (result == null) {
            // If no result exists for this party in the district, create a new one
            result = new Result();
            result.setDistrict(districtRepo.findById(candidate.getDistrictId())
                    .orElseThrow(() -> new RuntimeException("District not found!")));
            result.setParty(party);
            result.setVotes(1L); // Initialize vote count to 1
        } else {
            // Increment vote count
            result.setVotes(result.getVotes() + 1);
        }

        // Save the updated result
        resultServ.saveResult(result);
        logger.info("Vote count updated for party ID: {} in district ID: {}", partyId, candidate.getDistrictId());
    }
    
    public Optional<Candidate> getCandidateById(Long candidateId) {
        return candidateRepo.findById(candidateId);
    }

    public List<Candidate> getAllCandidates() {
        return candidateRepo.findAll();
    }

    public void deleteCandidateById(Long candidateId) {
        candidateRepo.deleteById(candidateId);
    }

    public List<Candidate> getCandidatesByRole(String role) {
        return candidateRepo.findByRole(role);
    }

    public List<Candidate> getCandidatesByDistrictId(Long districtId) {
        return candidateRepo.findByDistrictId(districtId);
    }
}