package com.cts.onlinevote.repo;

import com.cts.onlinevote.entity.Result;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResultRepo extends JpaRepository<Result, Long> {
    List<Result> findByDistrict_DistrictId(Long districtId);

    List<Result> findByParty_PartyId(Long partyId);
}