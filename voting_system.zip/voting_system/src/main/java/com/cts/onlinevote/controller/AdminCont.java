package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.*;
import com.cts.onlinevote.entity.*;
import com.cts.onlinevote.exception.CandidateNotFoundException;
import com.cts.onlinevote.service.*;
import io.jsonwebtoken.io.IOException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/admins")
public class AdminCont {

    @Autowired
    private CandidateServ candidateServ;

    @Autowired
    private StateServ stateServ;

    @Autowired
    private DistrictServ districtServ;

    @Autowired
    private PartyServ partyServ;

    @Autowired
    private ResultServ resultServ;

    @Autowired
    private HttpServletRequest request;

    private static final Logger logger = LoggerFactory.getLogger(AdminCont.class);

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/state")
    public ResponseEntity<State> createState(@RequestBody StateDTO stateDTO) {
        State savedState = stateServ.saveState(stateDTO);
        return ResponseEntity.ok(savedState);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/district")
    public ResponseEntity<District> createDistrict(@RequestBody DistrictDTO districtDTO) {
        District savedDistrict = districtServ.saveDistrict(districtDTO);
        return ResponseEntity.ok(savedDistrict);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/party")
    public ResponseEntity<Party> createParty(@RequestBody PartyDTO partyDTO) {
        Party savedParty = partyServ.saveParty(partyDTO);
        return ResponseEntity.ok(savedParty);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/party/{partyId}/symbol")
    public ResponseEntity<?> uploadPartySymbol(@PathVariable Long partyId, @RequestParam("file") MultipartFile file) throws java.io.IOException {
        logger.info("Content Type:{}", request.getContentType());
        try {
            partyServ.uploadPartySymbol(partyId, file);
            return ResponseEntity.ok("Party symbol uploaded successfully!");
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Could not upload symbol: " + e.getMessage());
        }
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/result")
    public ResponseEntity<List<ResultDTO>> getAllResults() {
        List<ResultDTO> results = resultServ.getResults();
        return ResponseEntity.ok(results);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/results/formatted")
    public ResponseEntity<List<String>> getFormattedResults() {
        List<String> formattedResults = resultServ.getFormattedResults();
        return ResponseEntity.ok(formattedResults);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/byrole/{role}")
    public ResponseEntity<List<Candidate>> getCandidatesByRole(@PathVariable String role) {
        List<Candidate> candidates = candidateServ.getCandidatesByRole(role);
        return ResponseEntity.ok(candidates);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getAll")
    public ResponseEntity<List<Candidate>> getAllCandidates() {
        List<Candidate> candidates = candidateServ.getAllCandidates();
        return ResponseEntity.ok(candidates);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getbyid/{id}")
    public ResponseEntity<Candidate> getCandidateById(@PathVariable Long id) {
        Optional<Candidate> candidate = candidateServ.getCandidateById(id);
        return candidate.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/district")
    public ResponseEntity<List<District>> getAllDistricts() {
        List<District> districts = districtServ.getAllDistricts();
        return ResponseEntity.ok(districts);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/party")
    public ResponseEntity<List<Party>> getAllParties() {
        List<Party> parties = partyServ.getAllParties();
        return ResponseEntity.ok(parties);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/state")
    public ResponseEntity<List<State>> getAllStates() {
        List<State> states = stateServ.getAllStates();
        return ResponseEntity.ok(states);
    }

    @DeleteMapping("/deletebyid/{id}")
    public ResponseEntity<String> deleteCandidateById(@PathVariable Long id) {
        candidateServ.deleteCandidateById(id);
        return ResponseEntity.ok("Candidate with id "+id+" is Deleted Successfully.");
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/update/candidate/{id}")
    public ResponseEntity<Candidate> updateCandidate(@PathVariable Long id, @RequestBody Candidate candidate) {
        Optional<Candidate> existingCandidate = candidateServ.getCandidateById(id);
        if (existingCandidate.isPresent()) {
            candidate.setCandidateId(id);
            return ResponseEntity.ok(candidateServ.saveCandidate(candidate));
        } else {
            throw new CandidateNotFoundException("Candidate not found!");
        }
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/delete/state/{id}")
    public ResponseEntity<Void> deleteStateById(@PathVariable Long id) {
    	stateServ.deleteStateById(id);
        return ResponseEntity.noContent().build();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/delete/district/{id}")
    public ResponseEntity<String> deleteDistrictById(@PathVariable Long id) {
    	districtServ.deleteDistrictById(id);
    	return ResponseEntity.noContent().build();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/delete/party/{id}")
    public ResponseEntity<String> deletePartyById(@PathVariable Long id) {
        partyServ.deletePartyById(id);
        return ResponseEntity.noContent().build();
    }
}