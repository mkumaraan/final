package com.cts.onlinevote.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Party {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long partyId;

    @Column(nullable = false, unique = true)
    @NotEmpty(message = "Party name cannot be empty")
    private String name;

    @Column(nullable = false)
    @NotEmpty(message = "Leader name cannot be empty")
    private String leaderName;

    @Lob
    @Column(columnDefinition = "MEDIUMBLOB")
    private byte[] symbolImage;

    public byte[] getSymbolImage() {
        return symbolImage;
    }

    public void setSymbolImage(byte[] symbolImage) {
        this.symbolImage = symbolImage;
    }

    @Column(nullable = false)
    private Long districtId;  // Changed to Column and made not nullable

    // Getters and Setters
    public Long getPartyId() {
        return partyId;
    }

    public void setPartyId(Long partyId) {
        this.partyId = partyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }

    public Long getDistrictId() {
        return districtId;
    }

    public void setDistrictId(Long districtId) {
        this.districtId = districtId;
    }
}