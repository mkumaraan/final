package com.cts.onlinevote.exception;

public class CandidatehasalreadyVotedException extends RuntimeException {

	public CandidatehasalreadyVotedException(String message) {
		super(message);
		
	}

}
