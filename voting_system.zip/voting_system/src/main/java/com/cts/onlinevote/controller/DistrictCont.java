package com.cts.onlinevote.controller;

import com.cts.onlinevote.dto.DistrictDTO;
import com.cts.onlinevote.entity.District;
import com.cts.onlinevote.service.DistrictServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/districts")
public class DistrictCont {

    @Autowired
    private DistrictServ districtServ;

    @PostMapping
    public ResponseEntity<District> createOrUpdateDistrict(@RequestBody DistrictDTO districtDTO) {
        District savedDistrict = districtServ.saveDistrict(districtDTO);
        return ResponseEntity.ok(savedDistrict);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<District>> getDistrictById(@PathVariable Long id) {
        Optional<District> district = districtServ.getDistrictById(id);
        if (district.isPresent()) {
            return ResponseEntity.ok(district);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<District>> getAllDistricts() {
        List<District> districts = districtServ.getAllDistricts();
        return ResponseEntity.ok(districts);
    }

    @GetMapping("/state/{stateId}")
    public ResponseEntity<List<District>> getDistrictsByStateId(@PathVariable Long stateId) {
        List<District> districts = districtServ.getDistrictsByStateId(stateId);
        return ResponseEntity.ok(districts);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDistrictById(@PathVariable Long id) {
        districtServ.deleteDistrictById(id);
        return ResponseEntity.noContent().build();
    }
}